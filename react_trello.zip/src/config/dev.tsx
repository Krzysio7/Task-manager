export const FirebaseConfig = {
    apiKey: "AIzaSyCfSVLJjGS90u9nJE4rFk-Q-aQB4CRf-Ko",
    authDomain: "trello-clone-ff88d.firebaseapp.com",
    databaseURL: "https://trello-clone-ff88d.firebaseio.com",
    projectId: "trello-clone-ff88d",
    storageBucket: "trello-clone-ff88d.appspot.com",
    messagingSenderId: "408778645796",
    appId: "1:408778645796:web:8e9c8a7b330c65530e53b1"
};