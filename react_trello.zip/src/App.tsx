import React from 'react';
import { DragDropContext } from 'react-beautiful-dnd';
import { connect } from "react-redux";
import { fetchData, sort, updateCardsIndexes } from './actions';
import './App.css';
import { TrelloList } from './components';
import ActionButton from './components/ActionButton';
import { ListObject } from './reducers/listsReducer';



interface ListProps {
  lists: Array<ListObject>;
  dispatch?: any;
  fetchData: any;
  sort: any;
  updateCardsIndexes: any;

}

class App extends React.Component<ListProps> {

  componentDidMount() {

    const { fetchData } = this.props;
    fetchData();
  }

  onDragEnd = (result: any) => {
    const { sort, lists, updateCardsIndexes } = this.props;
    const { destination, source, draggableId } = result;

    if (!destination) {

      return;
    }

    sort(
      source.droppableId,
      destination.droppableId,
      source.index,
      destination.index,
      draggableId
    );

    updateCardsIndexes(lists, source.droppableId);

  }

  render() {
    const { lists } = this.props;
    return (
      <DragDropContext onDragEnd={this.onDragEnd}>
        <div className="App">
          <h2>Trello Clone</h2>
          <div style={styles.listsContainer}>
            {lists.map((list: any) =>
              <TrelloList
                listID={list.id}
                key={list.id}
                title={list.title}
                cards={list.cards} />
            )}
            <ActionButton list={true} ></ActionButton>
          </div>
        </div>
      </DragDropContext>
    );
  }
}
const mapStateToProps = (state: ListProps) => ({
  lists: state.lists,
});



const styles = {
  listsContainer: {
    display: 'flex',
    marginRight: 8
  }
};
export default connect(mapStateToProps, { fetchData, sort, updateCardsIndexes })(App);
